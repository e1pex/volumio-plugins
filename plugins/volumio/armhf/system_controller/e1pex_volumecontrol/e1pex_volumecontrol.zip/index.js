'use strict';

var libQ = require('kew');
//var fs=require('fs-extra');
//var config = new (require('v-conf'))();
var exec = require('child_process').exec;
//var execSync = require('child_process').execSync;
var io = require('socket.io-client');
var socket = io.connect('http://localhost:3000');
var RotaryEnc=require('./RotaryEncoder');

module.exports = e1pexVolumecontrol;
function e1pexVolumecontrol(context) {
	var self = this;

	this.context = context;
	this.commandRouter = this.context.coreCommand;
	this.logger = this.context.logger;
	this.configManager = this.context.configManager;

}

e1pexVolumecontrol.prototype.onVolumioStart = function()
{
	var self = this;
	//var configFile=this.commandRouter.pluginManager.getConfigurationFile(this.context,'config.json');
	//this.config = new (require('v-conf'))();
	//this.config.loadFile(configFile);

    return libQ.resolve();
}

e1pexVolumecontrol.prototype.onStart = function() {
    var self = this;
	var defer=libQ.defer();
        self.constructRotaryEncoder(true);
	// Once the Plugin has successfull started resolve the promise
	defer.resolve();

    return defer.promise;
};

e1pexVolumecontrol.prototype.onStop = function() {
    var self = this;
    var defer=libQ.defer();

    // Once the Plugin has successfull stopped resolve the promise
    defer.resolve();

    return libQ.resolve();
};

e1pexVolumecontrol.prototype.onRestart = function() {
    var self = this;
    // Optional, use if you need it
};


// Configuration Methods -----------------------------------------------------------------------------

e1pexVolumecontrol.prototype.constructRotaryEncoder = function (initialize = false)
{
	try
	{
		//initialize GPIO-pins
		exec('/usr/bin/gpio -g mode 27 up', {uid:1000, gid:1000}, function (error, stout, stderr) {
                if(error)
                        console.log(stderr);
		});
		exec('/usr/bin/gpio -g mode 17 up', {uid:1000, gid:1000}, function (error, stout, stderr) {
                if(error)
                        console.log(stderr);
		});
	

		var self = this;
		//var CurrentVolume=1;
		//var NewVolume=CurrentVolume;
		self.RotaryEncoder = RotaryEnc(17,27,22);
		//socket.emit('getState', '');
		//socket.on('pushState', function(data) {
		//CurrentVolume= data.volume;
		//console.log('CurrentVolume on pushState: '+CurrentVolume);
		//});	
	self.RotaryEncoder.on('rotate', direction => {
	//NewVolume=CurrentVolume;
	//console.log('CurrentVolume when rotated: '+CurrentVolume);
	//console.log('NewVolume when rotated: '+NewVolume);
	if (direction=='Right'){
		//NewVolume=NewVolume+2;
		//console.log('NewVolume when raised: '+NewVolume);
		//console.log('CW');
		socket.emit('volume', '-');}	
	else if (direction=='Left'){
		//console.log('CCW');
		//NewVolume=NewVolume-2;
		//console.log('NewVolume when lowered: '+NewVolume);
		socket.emit('volume', '+');}	
	});

	self.RotaryEncoder.on('button', action => {
        //socket.emit('volume', 'toggle');
        if (action=='ShortPress'){
                socket.emit('volume', 'toggle');}
        else if (action=='LongPress'){
                socket.emit('shutdown');}
        });     








	}
	catch (ex)
	{
		console.log('Could not initiate rotary encoder with error: ' + ex);
	}
};
