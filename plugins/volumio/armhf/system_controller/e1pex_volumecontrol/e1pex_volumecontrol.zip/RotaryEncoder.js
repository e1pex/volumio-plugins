var Gpio = require('onoff').Gpio;
var EventEmitter = require('events').EventEmitter;

// var PinA = new Gpio(17, 'in', 'falling');
// var PinB = new Gpio(27, 'in', 'falling');
// var PinC = new Gpio(22, 'in', 'falling', {debounceTimeout: 10});

var ButtonPressTime=new Date().getTime();
var ButtonReleseTime=new Date().getTime(); 

 function Encoder(PinA, PinB, PinC){
	this.Pin1 = new Gpio(PinA, 'in', 'falling');
	this.Pin2 = new Gpio(PinB, 'in', 'falling');
	this.Pin3 = new Gpio(PinC, 'in', 'both', {debounceTimeout: 10});
	
        this.Pin1.watch((err,Pin1value) => {
        if (err) {
        throw err;
        }
        var Pin2value=this.Pin2.readSync();
        if (Pin1value < Pin2value) {
                //console.log('CW');
                //RotaryEnc.prototype.emit('rotate','Right');
                this.emit('rotate','Right');
                return this;
                }
         });

         this.Pin2.watch((err,Pin2value) => {
        if (err) {
                throw err;
        }
        var Pin1value=this.Pin1.readSync();
        if (Pin2value < Pin1value) {
                //console.log('CCW');
                //RotaryEnc.prototype.emit('rotate','Left');
                this.emit('rotate','Left');
		return this;
	        }
         });

         this.Pin3.watch((err,Pin3Value) => {
         if (err) {
                throw err;
         }
                //console.log('pressed');
         	//RotaryEnc.prototype.emit('button','pressed');
		if (Pin3Value ==1) {
		ButtonPressTime= new Date().getTime();
		};
		if (Pin3Value ==0) {
		ButtonReleaseTime= new Date().getTime();
		if (ButtonReleaseTime > ButtonPressTime + 10000) {
			this.emit('button','LongPress');
			}
		else if (ButtonReleaseTime < ButtonPressTime + 10000){
			this.emit('button','ShortPress')
			};
 		};
         	return this; 
	});

};

Encoder.prototype = EventEmitter.prototype;


module.exports = function RotaryEncoder(PinA, PinB, PinC) {
return new Encoder(PinA, PinB, PinC);
};

