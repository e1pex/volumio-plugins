var RotaryEnc=require('./RotaryEncoder');
var self = this;
        self.RotaryEncoder = RotaryEnc(17,27,22);

        self.RotaryEncoder.on('rotate', direction => {
        if (direction=='Right'){
        //socket.emit('volume', '+');     
        console.log('Rotated CW');}
        else if (direction=='Left'){
        //socket.emit('volume', '-');     
        console.log('Rotated CCW');}
        });

        self.RotaryEncoder.on('button', action => {
        //socket.emit('volume', 'toggle');
	if (action=='ShortPress'){
		console.log('Button was pressed a short time');}
	else if (action=='LongPress'){
		console.log('Button was pressed a long time');}
	});        
        //console.log ('Button: '+action);
        //});


